# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('id_generate', '0029_auto_20151223_0914'),
    ]

    operations = [
        migrations.AlterField(
            model_name='jaxiddetail',
            name='jaxid',
            field=models.ForeignKey(to='id_generate.JAXIdMasterList', blank=True, to_field='jaxid'),
        ),
        migrations.AlterField(
            model_name='jaxidmasterlist',
            name='jaxid',
            field=models.CharField(max_length=6, verbose_name='JAX ID', help_text='A unique ID string for every sample.', unique=True),
        ),
        migrations.AlterField(
            model_name='nucleicacidtype',
            name='code',
            field=models.CharField(max_length=20, verbose_name='Type Code', help_text='Nucleic acid type identifiying code.', blank=True, unique=True),
        ),
    ]
